#include"Core.h"
int main()
{
	run();
}