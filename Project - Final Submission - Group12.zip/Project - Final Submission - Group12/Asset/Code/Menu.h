#pragma once

#include <iostream>
#include "TexturePack.h"
#include "PreloadedData.h"
#include "Core.h"
bool runMenu(BackendGui& gui);

